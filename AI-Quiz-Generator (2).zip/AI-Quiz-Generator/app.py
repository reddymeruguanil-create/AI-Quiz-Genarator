from flask import Flask, render_template, request
from openai import OpenAI

app = Flask(__name__)

client = OpenAI (api_key="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")

def generate_quiz(text):
    prompt = f"""
    Generate 5 multiple choice questions from the following text.
    Provide 4 options and mark the correct answer.

    Text:
    {text}
    """

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content


@app.route('/', methods=['GET', 'POST'])
def index():
    quiz = ""
    if request.method == 'POST':
        user_input = request.form['content']
        quiz = generate_quiz(user_input)
    return render_template('index.html', quiz=quiz)


if __name__ == '__main__':
    app.run(debug=True)